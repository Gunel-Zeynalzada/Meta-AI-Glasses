package az.ada.glassesav.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.util.Log
import az.ada.glassesav.pipeline.AudioChunk
import az.ada.glassesav.pipeline.AudioChunkProcessor
import az.ada.glassesav.pipeline.AudioOrigin

/**
 * Keeps the audio of the most recent capture IN MEMORY ONLY (nothing is written to storage, SR9)
 * so it can be listened to after Stop. Capped at [MAX_SECONDS]; older audio is discarded.
 *
 * Playback goes to the PHONE SPEAKER on purpose: if it went to the glasses' open-ear speakers, a
 * new capture could pick it up again through the glasses microphones.
 */
class ReplayBuffer(context: Context) : AudioChunkProcessor {
  private val audioManager = context.applicationContext.getSystemService(AudioManager::class.java)
  private val chunks = ArrayDeque<ShortArray>()
  private var totalSamples = 0L
  @Volatile private var sampleRate = 16_000
  @Volatile var origin: AudioOrigin? = null
    private set

  @Volatile private var track: AudioTrack? = null
  private var playThread: Thread? = null

  val seconds: Double
    @Synchronized get() = totalSamples.toDouble() / sampleRate

  @Synchronized
  override fun onAudioChunk(chunk: AudioChunk) {
    if (chunk.channels != 1) return // all current sources are mono
    sampleRate = chunk.sampleRate
    origin = chunk.origin
    chunks.addLast(chunk.pcm)
    totalSamples += chunk.pcm.size
    val max = MAX_SECONDS.toLong() * sampleRate
    while (totalSamples > max && chunks.isNotEmpty()) totalSamples -= chunks.removeFirst().size
  }

  @Synchronized
  fun clear() {
    chunks.clear()
    totalSamples = 0
    origin = null
  }

  @Synchronized
  private fun snapshot(): ShortArray {
    val out = ShortArray(totalSamples.toInt())
    var pos = 0
    for (c in chunks) {
      c.copyInto(out, pos)
      pos += c.size
    }
    return out
  }

  /** Plays the buffered audio once. [onFinished] runs on a background thread. */
  fun play(onFinished: () -> Unit): Boolean {
    stopPlayback()
    val pcm = snapshot()
    if (pcm.isEmpty()) return false
    val rate = sampleRate
    val minBuf = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
    val t =
        AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(minBuf * 4)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
    audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
        ?.let { t.setPreferredDevice(it) }
    track = t
    playThread =
        Thread(
                {
                  try {
                    t.play()
                    var pos = 0
                    // Non-blocking writes, so Stop can always end this loop promptly.
                    while (pos < pcm.size && track === t) {
                      val n = t.write(pcm, pos, minOf(4096, pcm.size - pos), AudioTrack.WRITE_NON_BLOCKING)
                      when {
                        n < 0 -> break
                        n == 0 -> Thread.sleep(10)
                        else -> pos += n
                      }
                    }
                    // Let the last buffer drain before releasing.
                    if (track === t) Thread.sleep(300)
                  } catch (e: Exception) {
                    Log.e(TAG, "Playback failed", e)
                  } finally {
                    runCatching { t.stop() }
                    t.release()
                    if (track === t) track = null
                    onFinished()
                  }
                },
                "replay",
            )
            .apply { start() }
    return true
  }

  fun stopPlayback() {
    val t = track ?: return
    track = null // signals the play loop to end; the thread stops and releases the track
    runCatching { t.pause() }
    playThread?.join(1000)
    playThread = null
  }

  private companion object {
    const val TAG = "ReplayBuffer"
    const val MAX_SECONDS = 600 // 10 min = ~19 MB at 16 kHz mono 16-bit
  }
}
