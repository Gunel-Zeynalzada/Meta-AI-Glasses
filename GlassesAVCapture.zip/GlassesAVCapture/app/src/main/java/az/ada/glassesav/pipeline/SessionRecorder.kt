package az.ada.glassesav.pipeline

import android.graphics.Bitmap
import android.os.SystemClock
import java.io.BufferedWriter
import java.io.File
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

/**
 * Optional test recording for analysing source and synchronisation offline (e.g. in Python).
 * Off by default: in line with SR9 of the project paper, nothing is kept unless the user opts in.
 *
 * Output folder (pull with `adb pull`):
 *   /sdcard/Android/data/az.ada.glassesav/files/sessions/<yyyyMMdd_HHmmss>/
 *     audio.wav           16-bit PCM exactly as received (mono at the stream's rate)
 *     audio_chunks.csv    seq, origin, arrival_elapsed_ns, pts_us, samples, rate, channels, rms_dbfs
 *     video_frames.csv    seq, arrival_elapsed_ns, pts_us, width, height, bytes
 *     frame_<seq>.jpg     one JPEG per second, to check what the camera saw
 *     events.log          route diagnostics, state changes, user markers (clap test)
 */
class SessionRecorder(baseDir: File) : AudioChunkProcessor, VideoFrameProcessor {
  val dir: File =
      File(baseDir, SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())).apply { mkdirs() }

  private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "session-recorder") }
  private val audioCsv = writer("audio_chunks.csv", "seq,origin,arrival_elapsed_ns,pts_us,samples,sample_rate,channels,rms_dbfs")
  private val videoCsv = writer("video_frames.csv", "seq,arrival_elapsed_ns,pts_us,width,height,bytes")
  private val events = writer("events.log", null)
  private var wav: RandomAccessFile? = null
  private var wavDataBytes = 0L
  private var lastJpegNs = 0L
  @Volatile private var closed = false

  private fun submit(block: () -> Unit) {
    try {
      io.execute(block)
    } catch (_: java.util.concurrent.RejectedExecutionException) {
      // recorder already closed
    }
  }

  private fun writer(name: String, header: String?): BufferedWriter =
      File(dir, name).bufferedWriter().also { w -> header?.let { w.write(it); w.newLine() } }

  /** Called for EVERY video frame (bypasses the hub's frame dropping so the CSV is complete). */
  fun logVideoFrame(f: GlassesVideoFrame) {
    if (closed) return
    submit {
      videoCsv.write("${f.sequence},${f.arrivalElapsedNs},${f.presentationTimeUs},${f.width},${f.height},${f.i420.size}")
      videoCsv.newLine()
    }
  }

  /** VideoFrameProcessor: keeps one JPEG per second. */
  override fun onVideoFrame(frame: GlassesVideoFrame) {
    if (closed || frame.arrivalElapsedNs - lastJpegNs < 1_000_000_000L) return
    lastJpegNs = frame.arrivalElapsedNs
    val bmp = I420.toBitmap(frame)
    submit {
      FileOutputStream(File(dir, "frame_${frame.sequence}.jpg")).use {
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, it)
      }
      bmp.recycle()
    }
  }

  /** AudioChunkProcessor: appends to the WAV and logs timing. */
  override fun onAudioChunk(chunk: AudioChunk) {
    if (closed) return
    val rms = az.ada.glassesav.audio.AudioStats.rmsDbfs(chunk.pcm)
    submit {
      val out = wav ?: openWav(chunk.sampleRate, chunk.channels).also { wav = it }
      val bytes = ByteArray(chunk.pcm.size * 2)
      for (i in chunk.pcm.indices) {
        val s = chunk.pcm[i].toInt()
        bytes[2 * i] = (s and 0xFF).toByte()
        bytes[2 * i + 1] = ((s shr 8) and 0xFF).toByte()
      }
      out.write(bytes)
      wavDataBytes += bytes.size
      audioCsv.write(
          "${chunk.sequence},${chunk.origin.name},${chunk.arrivalElapsedNs},${chunk.presentationTimeUs ?: ""}," +
              "${chunk.pcm.size / chunk.channels},${chunk.sampleRate},${chunk.channels},${"%.1f".format(Locale.US, rms)}"
      )
      audioCsv.newLine()
    }
  }

  fun logEvent(message: String) {
    if (closed) return
    val t = SystemClock.elapsedRealtimeNanos()
    submit {
      events.write("$t\t$message")
      events.newLine()
    }
  }

  private fun openWav(rate: Int, channels: Int): RandomAccessFile {
    val f = RandomAccessFile(File(dir, "audio.wav"), "rw")
    f.setLength(0)
    f.write(wavHeader(rate, channels, 0))
    this.rate = rate
    this.channels = channels
    return f
  }

  private var rate = 16000
  private var channels = 1

  fun close() {
    if (closed) return
    closed = true
    submit {
      wav?.let {
        it.seek(0)
        it.write(wavHeader(rate, channels, wavDataBytes))
        it.close()
      }
      audioCsv.close()
      videoCsv.close()
      events.close()
    }
    io.shutdown()
  }

  private fun wavHeader(rate: Int, ch: Int, dataLen: Long): ByteArray {
    val byteRate = rate * ch * 2
    val b = java.nio.ByteBuffer.allocate(44).order(java.nio.ByteOrder.LITTLE_ENDIAN)
    b.put("RIFF".toByteArray()).putInt((36 + dataLen).toInt()).put("WAVE".toByteArray())
    b.put("fmt ".toByteArray()).putInt(16).putShort(1).putShort(ch.toShort()).putInt(rate)
    b.putInt(byteRate).putShort((ch * 2).toShort()).putShort(16)
    b.put("data".toByteArray()).putInt(dataLen.toInt())
    return b.array()
  }
}
