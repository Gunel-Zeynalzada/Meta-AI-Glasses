# Glasses AV Capture (Ray-Ban Meta Gen 2, Android)

Stage-1 capture foundation for the ADA University project *"English-Azerbaijani Translation of the
Target Speaker's Speech with Ray-Ban Meta (Gen 2) Glasses"*.

The app shows **live glasses video** and **live audio** in an Android app. On screen it shows
**where the audio physically comes from**, along with the evidence for that, and it keeps the
timestamps that later audiovisual (face/lip) processing will need.

> Status: **compiled successfully** (Gradle `assembleDebug`, SDK 1.1.0). It has **not yet been run
> on real glasses**. Every audio-source claim below must be confirmed with the hardware checklist
> in section 6.

---

## 1. What the SDK offers (verified 2026-11-24 against the official repo, tag "Release 1.1.0")

| Question | Answer | Source |
|---|---|---|
| Ray-Ban Meta Gen 2 supported? | Yes ("Ray-Ban Meta glasses (Gen 1 and Gen 2)") | wearables.developer.meta.com/docs/getting-started-toolkit |
| Versions for SDK 1.1.0 | Meta AI app **V292**, glasses firmware **V130**. SDK 1.0.1 needs firmware V128 | docs/develop/dat/version-dependencies |
| Android | Android 10+ per the docs. This app needs **Android 12+** (minSdk 31, same as Meta's sample) | getting-started, sample `app/build.gradle.kts` |
| Video | `Stream.videoStream`: I420 frames (or HEVC), 720x1280 / 504x896 / 360x640, 2/7/15/24/30 fps. Resolution and fps drop automatically when Bluetooth bandwidth is low (never below 15 fps) | docs/develop/dat/streaming |
| **Glasses mic through the SDK?** | **Yes, experimental, since SDK 1.0.0.** Set `StreamConfiguration.audioCodec = AudioCodec.PCM(...)`, then collect `Stream.audioStream` (`AudioFrame(buffer, presentationTimeUs)`). Rates: 16000/44100/48000 Hz. Needs `Permission.MICROPHONE` in the Meta AI app | CHANGELOG 1.0.0 "Camera audio streaming"; repo `plugins/mwdat-android/skills/audio-streaming/SKILL.md` |
| Same API as video? | Same `Stream` object, **separate Flow**. Audio shares the stream's state and errors | same skill file |
| Publishing | Experimental features "cannot be published yet"; fine for development and beta | CHANGELOG header, skill file |
| Second route | Standard Bluetooth **HFP/SCO**. Meta's own 1.x sample records the glasses mic this way, alongside the camera stream | sample `stream/AudioInputHandler.kt` |
| Camera and mic at the same time | SDK audio is by design inside the camera stream. HFP plus stream is used by Meta's sample, which notes that wideband SCO "eats camera-stream airtime" | same |

**Not documented, so it must be tested:** which of the glasses' microphones (or which beamformed
mix) feeds each route; whether HFP processing favours the wearer's voice; the clock origin of
`presentationTimeUs`; how far audio and video PTS are offset.

From inspecting the SDK binary (a hypothesis, but a strong one): the glasses send **AAC**, and the
SDK decodes it on the phone with `MediaCodec` (log tag `DAT:STREAM:AudioDecoder`). The AAC
compression adds latency and some coding loss, and the PCM is most likely 16-bit. The app measures
this ("bytes per sample", "measured rate").

## 2. Why your earlier test sounded like the phone mic

* Sample **0.9.0 and older** (`stream/AudioInputHandler.kt`, header *"Phone Microphone Audio
  Input"*) opened `AudioRecord(MediaRecorder.AudioSource.MIC)` with no Bluetooth routing. On
  Android that is **always the phone's built-in mic**.
* Your Gradle cache shows **SDK 1.0.1**. That sample routes to Bluetooth SCO and refuses the phone
  mic, so in 1.0.1 a "phone-sounding" result has other likely causes:
  1. Another Bluetooth headset/car kit was connected. The sample picks the *first* SCO device.
  2. The glasses' HFP mic is tuned for the wearer's voice (call use). A partner or the phone side
     sounds distant or "wrong", which is easy to mistake for the phone mic.
  3. The SCO route failed, the recording was video-only, and the audio you heard came from
     elsewhere, for example a screen recording.
* **Please send:** the sample version (commit/tag) you ran and a Logcat capture filtered to
  `AudioInputHandler` taken while recording. This sorts out 1-3 in minutes.

## 3. The three audio modes (exactly one per run)

| Mode | Path | Label on screen |
|---|---|---|
| **Glasses mic: DAT SDK stream** (default) | `Stream.audioStream` | green, "Glasses microphone (DAT SDK audio stream, experimental)" |
| Glasses mic: Bluetooth HFP | `AudioRecord` + `setCommunicationDevice(SCO)`, delivered **only if `routedDevice` is `TYPE_BLUETOOTH_SCO`** | green after route verification, amber before |
| PHONE mic fallback | `AudioRecord(MIC)` on `TYPE_BUILTIN_MIC` | **red, "PHONE MICROPHONE - NOT GLASSES AUDIO"** |

**Listening:** after **Stop**, tap **Play last capture** to hear the audio on the phone speaker,
labelled with its source. Up to the last 10 minutes are kept **in memory only** and replaced on the
next Start. For files, tick **Save test recording** (see section 6).

Every `AudioChunk` carries an `AudioOrigin`, so phone audio can never be passed off as glasses audio
further down the pipeline.

## 4. Windows setup, build, install

1. **Android Studio** (any recent version). **Gradle JDK must be 17 or 21.** Gradle 8.14.1 cannot
   run on JDK 25, and the build then fails with the bare message `25.0.4`.
   *Settings → Build, Execution, Deployment → Build Tools → Gradle → Gradle JDK* → choose
   `jbr-21` (download one from that menu if it isn't listed).
2. Unzip `GlassesAVCapture.zip`, then **File → Open** the `GlassesAVCapture` folder. Studio
   creates `local.properties` (SDK path) itself.
3. Phone: Android 12+, **Developer options → USB debugging** on, connect by USB, accept the RSA prompt.
4. Run ▶ (`app`). From a terminal instead:
   ```powershell
   .\gradlew.bat assembleDebug
   ```
   ```powershell
   adb install -r app\build\outputs\apk\debug\app-debug.apk
   ```

### Glasses and Meta AI configuration (you must do this yourselves)
1. Update the Meta AI app to **V292+** and the glasses firmware to **V130+** (Meta AI → glasses →
   General → About → Version). After the v128 update, Meta's known-issues page says to reboot the glasses.
2. Turn on **Developer Mode**: Meta AI → Settings → App Info → tap the app version **5 times** →
   toggle Developer Mode → Enable. With Developer Mode, `APPLICATION_ID`/`CLIENT_TOKEN` stay `0`
   (the build default).
3. Without Developer Mode (beta testers), register the app in the Wearables Developer Center,
   **enable the Camera and Audio Streaming capabilities**, and put the credentials in
   `local.properties` (never commit it):
   ```
   mwdat_application_id=YOUR_ID
   mwdat_client_token=YOUR_TOKEN
   ```
4. In the app: **Register** (opens Meta AI, approve, come back), then **Start**. On first start
   Meta AI asks for **Camera**, and in SDK-audio mode also **Microphone**.
5. For HFP mode only: in Android Bluetooth settings, the glasses must show **"Calls"/phone audio**
   enabled.

Lifecycle: capture runs only while the app is visible. Home, screen-off, glasses folded or
disconnected all stop it cleanly. Errors appear in red and in the event log.

## 5. Main files, and where your future code connects

```
app/src/main/java/az/ada/glassesav/
  MainActivity.kt                  Android + Meta AI permission dialogs, lifecycle stop
  capture/GlassesStreamController  DeviceSession -> Camera -> Stream; video + SDK audio flows
  capture/CaptureViewModel.kt      modes, state machine, source verdict, statistics
  audio/AudioRecordCapture.kt      HFP route (verified) and labelled phone-mic fallback
  audio/AudioRouteDiagnostics.kt   what Android reports about routing (Logcat tag AudioRoute)
  audio/AudioStats.kt              level meter, measured sample rate
  pipeline/MediaFrames.kt          GlassesVideoFrame, AudioChunk, AudioOrigin, processor interfaces
  pipeline/MediaHub.kt             fan-out to processors (video: latest-wins, audio: lossless FIFO)
  pipeline/I420.kt                 YUV->Bitmap, luma plane for detectors
  pipeline/SessionRecorder.kt      optional WAV + timestamp CSVs (off by default, SR9)
  ui/CaptureScreen.kt              Compose UI
```

**Plug-in point:** implement `VideoFrameProcessor` (face detection → face-centre baseline, Eq. 1;
lip ROI tracks for ASD) and `AudioChunkProcessor` (VAD, ASD audio branch, TSE input buffer). Then
register them in `CaptureViewModel.init`:
```kotlin
hub.addVideoProcessor(myFaceDetector)
hub.addAudioProcessor(myAsdAudioBuffer)
```
`I420.lumaPlane(frame)` gives a grayscale image straight away. Use `arrivalElapsedNs` (one phone
clock for both streams) to align audio and video, and `presentationTimeUs` to check spacing
within a stream.

### Timing limits (be careful in the thesis)
* `presentationTimeUs` origins are **undocumented**. In SDK mode the app shows
  "audio PTS − video PTS": if it stays roughly constant, the two share a clock.
* Arrival time includes Bluetooth transport, AAC/HEVC decode and buffering. Jitter is visible as
  "max gap between audio chunks" and in the CSVs.
* Resolution and fps can drop on their own under Bluetooth load. The real size is shown.
* End-to-end latency (lips move → frame in app) **is not measured by the app**. Use the clap
  test below and film the glasses and phone screen together with a 240 fps phone camera.

## 6. Hardware test checklist

Run each mode for about 60 s, with **Save test recording** on.

| # | Test | Expected (pass) |
|---|---|---|
| 1 | Start, SDK mode | session STARTED → stream STREAMING; video in preview; fps ≈ chosen; AUDIO SOURCE green |
| 2 | SDK format check | measured rate ≈ 16000 Hz (arrival and PTS); bytes/sample ≈ 2.0; "0 active AudioRecord session(s)" |
| 3 | **Cover test** | Cover the glasses' mic openings with a fingertip and speak: the level drops sharply. Cover the phone's bottom mic instead: no change. The phone-mic mode shows the reverse |
| 4 | **Separation test** | Phone in a closed drawer or another room (inside Bluetooth range), a speaker playing beside the phone: no rise in glasses audio. Speaking at the glasses: clear rise |
| 5 | **Tap test** | Lightly tap the glasses frame: sharp spike. Tap the phone body: none (in glasses modes) |
| 6 | Partner vs wearer | Partner speaks at 1 m in front, wearer silent, then the wearer speaks. Compare levels/WAVs **between SDK and HFP**. This decides which route suits a *conversation partner* (RQ1) |
| 7 | HFP mode | event log shows `routedDevice = BLUETOOTH_SCO(HFP) "<glasses name>"`. Turn glasses Bluetooth off: "route LOST", audio stops, it does **not** switch to the phone mic |
| 8 | Simultaneous A/V | Run 5 min in SDK mode and in HFP mode. Record whether fps / resolution drops and whether audio gaps exceed 100 ms |
| 9 | **Clap test** | Clap in front of the camera and press **Marker**. Offline, find the clap frame (JPEG/CSV) and the audio spike (WAV/CSV) to get the A/V offset |
| 10 | Disconnect | Fold the glasses: stream error HINGE_CLOSED / session STOPPED, red error, app stays usable; Start works again after unfolding |

Pull recordings:
```powershell
adb pull /sdcard/Android/data/az.ada.glassesav/files/sessions .
```

### Logcat to collect if something fails
```powershell
adb logcat -v time -s GlassesAV:* AudioRoute:* AudioRecordCapture:* GlassesStream:* MediaHub:* "DAT:STREAM:AudioDecoder:*" AudioRecord:* AudioService:* BluetoothHeadset:*
```
Send: that output, the on-screen **Audio route report** (tap Refresh while capturing), the app
version strings (Meta AI, glasses firmware, SDK 1.1.0), and the phone model and Android version.

Common failures: `Stream error: PERMISSIONS_DENIED` (grant Camera/Microphone in Meta AI → App
connections), `createSession failed: NOT_REGISTERED` (tap Register), no SDK audio frames (check
Developer Mode and the Audio Streaming capability, then share the `DAT:STREAM:AudioDecoder` log).

## 7. Sources
* github.com/meta/meta-wearables-dat-android: `CHANGELOG.md`, `samples/CameraAccess`,
  `plugins/mwdat-android/skills/{audio-streaming,camera-streaming,session-lifecycle}/SKILL.md`
* wearables.developer.meta.com/docs: getting-started-toolkit, develop/dat/streaming,
  develop/dat/version-dependencies, develop/dat/knownissues, build-integration-android
* Android: AudioManager.setCommunicationDevice, AudioRecord.getRoutedDevice,
  AudioManager.getActiveRecordingConfigurations, AudioTimestamp (developer.android.com)
